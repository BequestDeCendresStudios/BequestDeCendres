require_relative "Yumemoire/YumemoireFramework.rb"

#Game::Encyclopedia.translate
YumemoireEncyclopedia::Encyclopedia.beastiary

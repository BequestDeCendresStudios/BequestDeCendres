require_relative "Yumemoire/YumemoireFramework.rb"
#require_relative "Yumemoire/bugtest.rb"

YumemoireFramework::Title.main

#YumemoireStats::GlobalStats.assign_metrics
#YumemoireEncyclopedia::HumanMode.parser

#YumemoireHumanMode::HumanMode.parser

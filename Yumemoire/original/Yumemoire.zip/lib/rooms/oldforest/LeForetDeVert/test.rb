print "\e[8;46;98t"

position_1 = File.read("player_position1.txt").strip.to_s

puts position_1

gets.chomp

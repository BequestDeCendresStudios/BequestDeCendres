first_hex = File.read("_results/first_mix.txt").strip.to_s
second_hex = File.read("_results/second_mix.txt").strip.to_s

puts first_hex
puts second_hex

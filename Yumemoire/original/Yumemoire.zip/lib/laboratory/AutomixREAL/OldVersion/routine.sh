ruby gui.rb
ruby first_mixer.rb
ruby second_mixer.rb
ruby remix.rb

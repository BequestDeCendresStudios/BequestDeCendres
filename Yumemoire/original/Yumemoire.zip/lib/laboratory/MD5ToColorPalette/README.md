# MD5ToColorPalette
A method of using MD5 to directly convert poetry to color palettes.

module YumemoireFramework
  class Error < StandardError; end

  class Title

    def self.main
      puts "\e[38;2;187;127;118m  \e[8;42;107t"

      loop do
        system("clear")

        title_text = File.read("lib/images/title/title2.txt")

        puts title_text
  
        print "What would you like to do? [ Play / Language / Quit ] >> "; option = gets.chomp

        if option == "Play"
          YumemoireStats::GlobalStats.assign_metrics

          YumemoireHumanMode::HumanMode.parser
        elsif option == "Language"
          print ">> Glossary or translation? >> "; lang_choice = gets.chomp

          if    lang_choice == "Glossary"
            YumemoireEncyclopedia::Encyclopedia.study
          elsif lang_choice == "Translate"
            YumemoireEncyclopedia::Encyclopedia.translate
          elsif lang_choice == "Detect Poison"
            YumemoireEncyclopedia::Encyclopedia.detect_poison
          else
            puts ">> This language option does not exist."
          end
        elsif option == "Quit"
          system("clear")

          abort
        else
          puts "Unregonized command..."

          sleep(1.5)
        end
      end
    end

  end

end

module YumemoireStats
  class GlobalStats
    def self.assign_metrics
      ##########################################################################################
      #                       Global variables that effect gameplay.                           #
      ##########################################################################################
      # Standard Operations
      $stalemates    = 0 # Keeps track of how many stalemates
      $player_struck = 0 # Keeps track of how many times player hit the enemy.
      $enemy_struck  = 0 # Keeps track of how many times enemy hit the player.

      # Current Lunar Phase
      $current_phase =  0 # File.read("lib/data/lunar_calender/current_phase.txt").strip.to_i # 0

      ## Amount of days in a year.
      $current_day = 0
      $lunar_ticks = 30

      # One allows you to always maintain a certain maximum reset hp. The other can be altered.
      $true_reset_hp = File.read("lib/player_stats/true_reset_hp.txt").strip.to_i
      $reset_hp      = File.read("lib/player_stats/reset_hp.txt").strip.to_i

      # Standard base stats
      $personal_demon_metric = 0 # File.read("lib/data/user/personal_demon_metric.txt").strip.to_i
      $player_healing_rate   = 4 # File.read("lib/player_stats/player_healing_rate.txt").strip.to_i

      $player_hp   = 10 # File.read("lib/player_stats/player_hp.txt").strip.to_i
      $player_atk  =  4 # File.read("lib/player_stats/player_atk.txt").strip.to_i
      $player_heal =  2 # $player_healing_rate

      $enemy_hp   = 10
      $enemy_atk  = 2
      $enemy_heal = 4

      # Resets the player's HP
      $true_hp_reset = 10
      $reset_hp = 10
    end
  end
end

module YumemoireEnvironmental
  class LunarCalender
    ##########################################################################################
    #                                    Lunar Phase                                         #
    ##########################################################################################
    def self.lunar_cycle
      lunar_phases = [0, 1, 2, 3, 4, 5, 6, 7]

      # The current lunar phase mod 7
      current_phase  = $current_phase % 7
      $current_phase = $current_phase + 1 % 7

      if    current_phase == lunar_phases[0]
        puts "\e[38;2;187;127;118mLa phase lunaire actuelle est: Full Moon. Réinitialisation des statistiques du joueur...\e[0m"

        sleep(1)

        $player_hp   = -10
        $player_atk  =  4
        $player_heal =  2

        # Negative Healing ala illness
        #$player_illness = 2
      elsif current_phase == lunar_phases[1]
        puts "\e[38;2;187;127;118mLa phase lunaire actuelle est: Waning Gibbous. Réinitialisation des statistiques du joueur...\e[0m"

        sleep(1)

        $player_hp   = -8
        $player_atk  = 6
        $player_heal = 2

        # Negative Healing ala illness
        #$player_illness = 2
      elsif current_phase == lunar_phases[2]
        puts "\e[38;2;187;127;118mLa phase lunaire actuelle est: First Quarter. Réinitialisation des statistiques du joueur...\e[0m"

        sleep(1)

        $player_hp   = -6
        $player_atk  = 8
        $player_heal = 2

        # Negative Healing ala illness
        #$player_illness = 2
      elsif current_phase == lunar_phases[3]
        puts "\e[38;2;187;127;118mLa phase lunaire actuelle est: Waxing Crescent. Réinitialisation des statistiques du joueur...\e[0m"

        sleep(1)

        $player_hp   = -4
        $player_atk  = 8
        $player_heal = 2

        # Negative Healing ala illness
        #$player_illness = 2
      elsif current_phase == lunar_phases[4]
        puts "\e[38;2;187;127;118mLa phase lunaire actuelle est: New Moon. Réinitialisation des statistiques du joueur...\e[0m"

        sleep(1)

        $player_hp   = -2
        $player_atk  = 10
        $player_heal = 2

        # Negative Healing ala illness
        #$player_illness = 8

        gets.chomp

        abort
      elsif current_phase == lunar_phases[5]
        puts "\e[38;2;187;127;118mLa phase lunaire actuelle est: Waning Crescent. Réinitialisation des statistiques du joueur...\e[0m"

        sleep(1)

        $player_hp   = -5
        $player_atk  = 8
        $player_heal = 2

        # Negative Healing ala illness
        #$player_illness = 6
      elsif current_phase == lunar_phases[6]
        puts "\e[38;2;187;127;118mLa phase lunaire actuelle est: Third Quarter. Réinitialisation des statistiques du joueur...\e[0m"

        sleep(1)

        $player_hp   =  -7
        $player_atk  = 10
        $player_heal =  2

        # Negative Healing ala illness
        #$player_illness = 4
      elsif current_phase == lunar_phases[7]
        puts "\e[38;2;187;127;118mLa phase lunaire actuelle est: Waning Gibbous. Réinitialisation des statistiques du joueur...\e[0m"

        sleep(1)

        $player_hp   = -9
        $player_atk  = 2
        $player_heal = 2

        # Negative Healing ala illness
        #$player_illness = 2
      end

      sleep(1.5)
    end
  end

module YumemoireVillager
  class Marketplace
    #######################################################################################
    #                                  Inn Mechanics                                      #
    #######################################################################################
    # Subroutine for staying at an inn.
    def self.stay_at_inn
      if $player_hp > 0
        if $player_yen >= 172
          sleep(1.5)

          puts "\e[38;2;187;127;118mInn Keeper: Have a nice stay!\e[0m"

          $player_hp = $reset_hp
          $player_yen = $player_yen - 172

          sleep(1.5)
        else
          sleep(1.5)

          puts "\e[38;2;187;127;118mInn Keeper: Seems you don't have enough Yen.\e[0m"

          sleep(1.5)
        end
      else
        sleep(1.5)

        puts "\e[38;2;187;127;118mInn Keeper: Seems like you don't need the sleep!\e[0m"

        sleep(1.5)
      end
    end

    ########################################################################################
    #                                 Armoury Mechanics                                    #
    ########################################################################################
    def self.visit_armoury
    end
  end
end

module YumemoireDialogue
  class DialogueScript
    #######################################################################################
    #                                 Dialogue Script                                     #
    #######################################################################################
    def self.word_lengths
      def self.one_character
        dipthongs = File.readlines("lib/data/dipthongs.txt")

        generated_word = dipthongs.sample.strip.to_s

        masculine      = generated_word.chop +  "u"
        feminine       = generated_word.chop +  "a"
        plural         = generated_word.chop + "os"
    
        puts "Single"
        puts "#{masculine} #{feminine} #{plural}"

        puts " "
      end

      def self.three_character
        dipthongs = File.readlines("lib/data/dipthongs.txt")

        component_one = dipthongs.sample.strip.to_s
        component_two = dipthongs.sample.strip.to_s
        component_tre = dipthongs.sample.strip.to_s

        generated_word = component_one + component_two + component_tre

        masculine      = generated_word.chop +  "u"
        feminine       = generated_word.chop +  "a"
        plural         = generated_word.chop + "os"
    
        puts "Triple"
        puts "#{masculine} #{feminine} #{plural}"

        puts " "
      end

      def self.five_character
        dipthongs = File.readlines("lib/data/dipthongs.txt")

        component_one = dipthongs.sample.strip.to_s
        component_two = dipthongs.sample.strip.to_s
        component_tre = dipthongs.sample.strip.to_s
        component_fro = dipthongs.sample.strip.to_s
        component_fiv = dipthongs.sample.strip.to_s

        generated_word = component_one + component_two + component_tre + component_fro + component_fiv

        masculine      = generated_word.chop +  "u"
        feminine       = generated_word.chop +  "a"
        plural         = generated_word.chop + "os"
    
        puts "Septuple"
        puts "#{masculine} #{feminine} #{plural}"

        puts " "
      end

      def self.seven_character
        dipthongs = File.readlines("lib/data/dipthongs.txt")

        component_one = dipthongs.sample.strip.to_s
        component_two = dipthongs.sample.strip.to_s
        component_tre = dipthongs.sample.strip.to_s
        component_fro = dipthongs.sample.strip.to_s
        component_fiv = dipthongs.sample.strip.to_s
        component_six = dipthongs.sample.strip.to_s
        component_sev = dipthongs.sample.strip.to_s

        generated_word = component_one + component_two + component_tre + component_fro + component_fiv + component_six + component_sev

        masculine      = generated_word.chop +  "u"
        feminine       = generated_word.chop +  "a"
        plural         = generated_word.chop + "os"
  
        puts "Seven"
        puts "#{masculine} #{feminine} #{plural}"

        puts " "
      end

      def self.procedural_euphemisms
        #          Te      Ta     Tos
        # Te    Te,Te   Te,Ta  Te,Tos
        # Ta    Ta,Te   Ta,Ta  Ta,Tos
        # Tos  Tos,Te  Tos,Ta Tos,Tos

        7.times do

          hybrid_genders = [
            [["Te",  "Te"], ["Te",  "Ta"], ["Te",  "Tos"]],
            [["Ta" , "Te"], ["Ta",  "Ta"], ["Ta",  "Tos"]],
            [["Tos", "Te"], ["Tos", "Ta"], ["Tos", "Tos"]],
          ]

          gender_row_options = [0, 1, 2]
          gender_col_options = [0, 1, 2]
          gender_arr_options = [0, 1]

          gender_cur_row = gender_row_options.sample
          gender_cur_col = gender_col_options.sample
          gender_cur_arr = gender_arr_options.sample

          h_gender = hybrid_genders[gender_cur_row][gender_cur_col][gender_cur_arr]

          #               ie  shado gareji ribingurumu  roka   daidakoro shinku aisubokkusu uindo  basurumu shinshitsu
          # ie            i,i  i,s1  i,g    i,r1         i,r2   i,d       i,s2    i,a         i,u    i.b      i,s3     # House
          # shado        s1,i s1,s1 s1,g   s1,r1        s1,r2  s1,d      s1,s2   s1,a        s1,u   s1.b     s1,s3     # Slope
          # gareji        g,i  g,s1  g,g    g,r1         g,r2   g,d       g,s2    g,a         g,u    g.b      g,s3     # Garage
          # ribingurumu  r1,i r1,s1 r1,g   r1,r1        r1,r2  r1,d      r1,s2   r1,a        r1,u   r1.b     r1,s3     # Living Room
          # roka          g,i  g,s1  g,g    g,r1         g,r2   g,d       g,s     g,a         g,u    g.b      g,s3     # Fridge
          # daidakoro     d,i  d,s1  d,g    d,r1         d,r2   d,d       d,s     d,a         d,u    d.b      d,s3     # The first time
          # shinku       s2,i s2,s1 s2,g   s2,r1        s2,r2  s2,d      s2,s    s2,a        s2,u   s2.b     s2,s3     # Sink
          # aisubokkusu   a,i  a,s1  a,g    a,r1         a,r2   a,d       a,s     a,a         a,u    a.b      a,s2     # Ice Box
          # uindo         u,i  u,s1  u,g    u,r1         u,r2   u,d       u,s     u,a         u,u    u.b      u,s2     # Window
          # basurumu      b,i  b,s1  b,g    b,r1         b,r2   b,d       b,s     b,a         b,u    b.b      b,s2     # Bathroom
          # shinshitsu   s3,i s3,s1 s3,g   s3,r1        s3,r2  s3,d      s3,s    s3,a         s3,u  s3.b     s3,s2     # Bedroom

          locations = [
            [["Ie",          "Ie"], ["Ie",          "Shado"], ["Ie",          "Gareji"], ["Ie",          "Ribingurumu"], ["Ie",          "Roka"], ["Ie",          "Daidakoro"], ["Ie",          "Shinku"], ["Ie",          "Aisubokkusu"], ["Ie",          "Uindo"], ["Ie",          "Basurumu"], ["Ie",          "Shinshitsu"]],
            [["Shadi" ,      "Ie"], ["Shado",       "Shado"], ["Shado",       "Gareji"], ["Shado",       "Ribingurumu"], ["Shado" ,      "Roka"], ["Shado",       "Daidakoro"], ["Shado",       "Shinku"], ["Shado",       "Aisubokkusu"], ["Shado",       "Uindo"], ["Shado",       "Basurumu"], ["Shado",       "Shinshitsu"]],
            [["Gareji",      "Ie"], ["Gareji",      "Shado"], ["Gareji",      "Gareji"], ["Gareji",      "Ribingurumu"], ["Gareji",      "Roka"], ["Gareji",      "Daidakoro"], ["Gareji",      "Shinku"], ["Gareji",      "Aisubokkusu"], ["Garehi",      "Uindo"], ["Gareji",      "Basurumu"], ["Shadow",      "Shinshitsu"]],
            [["Ribingurumu", "Ie"], ["Ribingurumu", "Shado"], ["Ribingurumu", "Gareji"], ["Ribingurumu", "Ribingurumu"], ["Ribingurumu", "Roka"], ["Ribingurumu", "Daidakoro"], ["Ribingurumu", "Shinku"], ["Ribingurumu", "Aisubokkusu"], ["Ribingurumu", "Uindo"], ["Ribingurumu", "Basurumu"], ["Ribingurumu", "Shinshitsu"]],
            [["Roka",        "Ie"], ["Roka",        "Shado"], ["Roka",        "Gareji"], ["Roka",        "Ribingurumu"], ["Roka",        "Roka"], ["Roka",        "Daidakoro"], ["Roka",        "Shinku"], ["Roka",        "Aisubokkusu"], ["Roka",        "Uindo"], ["Roka",        "Basurumu"], ["Roka",        "Shinshitsu"]],
            [["Daidakoro",   "Ie"], ["Daidakoro",   "Shado"], ["Daidakoro",   "Gareji"], ["Daidakoro",   "Ribingurumu"], ["Daidakoro",   "Roka"], ["Daidakoro",   "Daidakoro"], ["Daidakoro",   "Shinku"], ["Daidakoro",   "Aisubokkusu"], ["Daidakoro",   "Uindo"], ["Daidakoro",   "Basurumu"], ["Daidakoro",   "Shinshitsu"]],
            [["Shinku",      "Ie"], ["Shinku",      "Shado"], ["Shinku",      "Gareji"], ["Shinku",      "Ribingurumu"], ["Shinku",      "Roka"], ["Shinku",      "Daidakoro"], ["Shinku",      "Shinku"], ["Shinku",      "Aisubokkusu"], ["Shinku",      "Uindo"], ["Shinku",      "Basurumu"], ["Shinku",      "Shinshitsu"]],
            [["aisubokkusu", "Ie"], ["Aisubokkusu", "Shado"], ["Aisubokkusu", "Gareji"], ["Aisubokkusu", "Ribingurumu"], ["Aisubokkusu", "Roka"], ["Aisubokkusu", "Daidakoro"], ["Aisubokkusu", "Shinku"], ["Aisubokkusu", "Aisubokkusu"], ["Aisubokkusu", "Uindo"], ["Aisubokkusu", "Basurumu"], ["Aisubokkusu", "Shinshitsu"]],
            [["Uindo",       "Ie"], ["Uindo",       "Shado"], ["Uindo",       "Gareji"], ["Uindo"      , "Ribingurumu"], ["Uindo",       "Roka"], ["Uindo",       "Daidakoro"], ["Uindo",       "Shinku"], ["Uindo",       "Aisubokkusu"], ["Uindo",       "Uindo"], ["Uindo",       "Basurumu"], ["Uindo",       "Shinshitsu"]],
            [["Basurumu",    "Ie"], ["Basurumu",    "Shado"], ["Basurumu",    "Gareji"], ["Basurumu",    "Ribingurumu"], ["Basurumu",    "Roka"], ["Basurumu",    "Daidakoro"], ["Basurumu",    "Shinku"], ["Basurumu",    "Aisubokkusu"], ["Basurumu",    "Uindo"], ["Basurumu",    "Basurumu"], ["Basurumu",    "Shinshitsu"]],
            [["Shinshitsu",  "Ie"], ["Shinsitsu",   "Shado"], ["Shinsitsu",   "Gareji"], ["Shinshitsu",  "Ribingurumu"], ["Shinshitsu",  "Roka"], ["Shinshitsu",  "Daidakoro"], ["Shinshitsu",  "Shinku"], ["Shinshitsu",  "Aisubokkusu"], ["Shinshitsu",  "Uindo"], ["Shinshitsu",  "Basurumu"], ["Shinshitsu",  "Shinshitsu"]],
          ]

          location_row_options = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
          location_col_options = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
          location_arr_options = [0, 1]

          l_cur_row = location_row_options.sample
          l_cur_col = location_col_options.sample
          l_cur_arr = location_arr_options.sample

          cur_location = locations[l_cur_row][l_cur_col][l_cur_arr]

          #            guache entre sortie porte canape pratiquer manger lave  merde  dorm  mur
          # guache      g,g    g,e   g,s    g,p   g,c    g,p       g,m1   g,l   g,m2   g,d   g,m3 # Gouache paint
          # entre       e,g    e,e   e,s    e,p   e,c    e,p       e,m1   e,l   e,m2   e,d   e,m3 # Between
          # sortie      s,g    s,e   s,s    s,p   s,c    s,p       s,m1   s,l   s,m2   s,d   s,m3 # Exit
          # porte       p,g    p,e   p,s    p,p   p,c    p,p       p,m1   p,l   p,m2   p,d   p,m3 # Door
          # canape      c,g    c,e   c,s    c,p   c,c    c,p       c,m1   c,l   c,m2   c,d   c,m3 # Couch
          # pratiquer   p,g    p,e   p,s    p,p   p,c    p,p       p,m1   p,l   p,m2   p,d   p,m3 # Practice
          # manger     m1,g   m1,e  m1,s   m1,p  m1,c   m1,p      m1,m1  m1,l  m1,m2  m1,d  m1,m3 # To Eat
          # lave        l,g    l,e   l,s    l,p   l,c    l,p       l,m1   l,l   l,m2   l,d   l,m3 # Washed / Wash
          # merde      m2,g   m2,e  m2,s   m2,p  m2,c   m2,p      m2,m1  m2,l  m2,m2  m2,d  m2,m3 # Shit / Poo ( informal )
          # dorm        d,g    d,e   d,s    d,p   d,c    d,p       d,m1   d,l   d,m2   d,d   d,m3 # Sleep
          # mur        m3,g   m3,e  m3,s   m3,p  m3,c   m3,p      m3,m1  m3,l  m3,m   m3,d  m3,m2 # Wall

          #begin

          verbs = [
            [["gouache",   "gouache"], ["gouache",   "entre"], ["gouache",   "sortie"], ["gouache",   "porte"], ["gouache",   "canape"], ["gouache",   "pratiquer"], ["gouache",   "manger"], ["gouache",   "laver"], ["gouache",   "merde"], ["gouache",   "dorm"], ["gouache",   "mur"]],
            [["entre",     "gouache"], ["entre",     "entre"], ["entre",     "sortie"], ["entre",     "porte"], ["entre",     "canape"], ["entre",     "pratiquer"], ["entre",     "manger"], ["entre",     "laver"], ["entre",     "merde"], ["entre",     "dorm"], ["entre",     "mur"]],
            [["sortie",    "gouache"], ["sortie",    "entre"], ["sortie",    "sortie"], ["sortie",    "porte"], ["sortie",    "canape"], ["sortie",    "pratiquer"], ["sortie",    "manger"], ["sortie",    "laver"], ["sortie",    "merde"], ["sortie",    "dorm"], ["sortie",    "mur"]],
            [["porte",     "gouache"], ["porte",     "entre"], ["porte",     "sortie"], ["porte",     "porte"], ["porte",     "canape"], ["porte",     "pratiquer"], ["porte",     "manger"], ["porte",     "laver"], ["porte",     "merde"], ["porte",     "dorm"], ["prte",      "mur"]],
            [["canape",    "gouache"], ["canape",    "entre"], ["canape",    "sortie"], ["canape",    "porte"], ["canape",    "canape"], ["canape",    "pratiquer"], ["canape",    "manger"], ["canape",    "laver"], ["canape",    "merde"], ["canape",    "dorm"], ["canape",    "mur"]],
            [["pratiquer", "gouache"], ["pratiquer", "entre"], ["pratiquer", "sortie"], ["pratiquer", "porte"], ["pratiquer", "canape"], ["pratiquer", "pratiquer"], ["pratiquer", "manger"], ["pratiquer", "laver"], ["pratiquer", "merde"], ["pratiquer", "dorm"], ["pratiquer", "mur"]],
            [["manger",    "gouache"], ["manger",    "entre"], ["manger",    "sortie"], ["manger",    "porte"], ["manger",    "canape"], ["manger",    "pratiquer"], ["manger",    "manger"], ["manger",    "laver"], ["manger",    "merde"], ["manger",    "dorm"], ["manger",    "mur"]],
            [["laver",     "gouache"], ["laver",     "entre"], ["laver",     "sortie"], ["laver",     "porte"], ["laver",     "canape"], ["laver",     "pratiquer"], ["laver",     "manger"], ["laver",     "laver"], ["laver",     "merde"], ["laver",     "dorm"], ["laver",     "mur"]],
            [["merde",     "gouache"], ["merde",     "entre"], ["merde" ,    "sortie"], ["merde",     "porte"], ["merde",     "canape"], ["merde",     "pratiquer"], ["merde",     "manger"], ["merde",     "laver"], ["merde",     "merde"], ["merde",     "dorm"], ["merde",     "mur"]],
            [["dorm",      "gouache"], ["dorm",      "entre"], ["dorm",      "sortie"], ["dorm",      "porte"], ["dorm",      "canape"], ["dorm",      "pratiquer"], ["dorm",      "manger"], ["dorm",      "laver"], ["dorm",      "merde"], ["dorm",      "dorm"], ["dorm",      "mur"]],
            [["mur",       "gouache"], ["mur",       "entre"], ["mur",       "sortie"], ["mur",       "porte"], ["mur",       "canape"], ["mur",       "pratiquer"], ["mur",       "manger"], ["mur",       "laver"], ["mur",       "merde"], ["mur",       "dorm"], ["mur",       "mur"]],
          ]

          verb_row_options = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
          verb_col_options = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
          verb_arr_options = [0, 1]

          v_cur_row = verb_row_options.sample
          v_cur_col = verb_row_options.sample
          v_cur_arr = verb_arr_options.sample

          cur_verb = verbs[v_cur_row][v_cur_col][v_cur_arr]

          #rescue
            #puts "No such verb on #{v_cur_row} #{v_cur_col} #{v_cur_arr}"
          #end

          ## Create word
          current_word = "#{h_gender} #{cur_location}#{cur_verb}"
          #current_word = "#{cur_verb}"

            #training_data = " => portmanteau.train(:formal, '#{current_word}', 'word')\n"

            File.open("_input/portmanteau.txt", "a") { |f|
              f.puts current_word
            }
            #puts  training_data
          end
        end
      end
    end
  end
end

module YumemoireDamage
  class DamageFormulas
    ########################################################################################
    #                      Damage Formulas For Players And Enemies                         #
    ########################################################################################
    def self.player_damage_rate
      #set_player_stats
      #set_enemy_stats

      def_dice = [ 'full_damage', 'half_damage', 'missed', 'critical' ]

      roll_dice = def_dice.sample

      if roll_dice == 'full_damage'
        damage = $player_atk

        $enemy_hp = $enemy_hp - damage

        puts "\e[38;2;187;127;118mSister Chaos has attacked Sister Order for full damage.\e[0m"

        sleep(1.5)
      elsif roll_dice == 'critical'
        damage = $player_atk * 2

        $enemy_hp = $enemy_hp - damage

        puts "\e[38;2;187;127;118mSister Chaos has attacked Sister Order for double damage.\e[0m"

        sleep(1.5)
      elsif roll_dice == 'half_damage'
        damage = $player_atk / 2

        $enemy_hp = $enemy_hp - damage

        puts "\e[38;2;187;127;118mSister Chaos has attacked Sister Order for half damage.\e[0m"

        sleep(1.5)
      elsif roll_dice == 'missed'
        puts "\e[38;2;187;127;118mSister Chaos has missed Sister Order.\e[0m"

        sleep(1.5)
      end
    end

    def self.enemy_damage_rate
      #set_player_stats
      #set_enemy_stats

      def_dice = [ 'full_damage', 'half_damage', 'missed', 'critical' ]

      roll_dice = def_dice.sample

      if roll_dice == 'full_damage'
        damage = $enemy_atk

        $player_hp = $player_hp - damage

        puts "\e[38;2;187;127;118mSister Order has attacked Sister Chaos for full damage.\e[0m"

        sleep(1.5)
      elsif roll_dice == 'critical'
        damage = $enemy_atk * 2

        $player_hp = $player_hp - damage

        puts "\e[38;2;187;127;118mSister Order has attacked Sister Chaos for double damage.\e[0m"

        sleep(1.5)
      elsif roll_dice == 'half_damage'
        damage = $enemy_atk / 2

        $player_hp = $player_hp - damage

        puts "\e[38;2;187;127;118mSister Order has attacked Sister Chaos for half damage.\e[0m"

        sleep(1.5)
      elsif roll_dice == 'missed'
        puts "\e[38;2;187;127;118mSister Order has missed the Sister Chaos.\e[0m"

        sleep(1.5)
      end
    end
  end
end

#module YumemoireGribatomaton
#  class Gribatomaton
#    ###################################################################################
#    #                            Upgrades For Pet Spider                              #
#    ###################################################################################
#    def self.level_one_spider
#      $spider_hp   = File.read("pet_stats/spider_hp.txt").strip.to_s
#      $spider_atk  = File.read("pet_stats/spider_atk.txt").strip.to_s
#      $spider_heal = File.read("pet_stats/spider_heal.txt").strip.to_s
#    end
#
#    def self.level_two_spider
#      $spider_hp   = File.read("pet_stats/spider_hp.txt").strip.to_s
#      $spider_atk  = File.read("pet_stats/spider_atk.txt").strip.to_s
#      $spider_heal = File.read("pet_stats/spider_heal.txt").strip.to_s
#
#      File.open("pet_stats/spider_hp.txt", "w") { |f|
#        $spider_hp = $spider_hp + 3
#
#        f.puts $spider_hp
#      }
#
#      File.open("pet_stats/spider_atk.txt", "w") { |f|
#        $spider_atk = $spider_atk + 3
#
#        f.puts $spider_atk
#      }
#
#      File.open("pet_stats/spider_heal.txt", "w") { |f|
#        $spider_heal = $spider_heal + 3
#
#        f.puts $spider_heal
#      }
#    end
#
#    def self.level_three_spider
#      $spider_hp   = File.read("pet_stats/spider_hp.txt").strip.to_s
#      $spider_atk  = File.read("pet_stats/spider_atk.txt").strip.to_s
#      $spider_heal = File.read("pet_stats/spider_heal.txt").strip.to_s
#
#      File.open("pet_stats/spider_hp.txt", "w") { |f|
#        $spider_hp = $spider_hp + 5
#
#        f.puts $spider_hp
#      }
#
#      File.open("pet_stats/spider_atk.txt", "w") { |f|
#        $spider_atk = $spider_atk + 5
#
#        f.puts $spider_atk
#      }
#
#      File.open("pet_stats/spider_heal.txt", "w") { |f|
#        $spider_heal = $spider_heal + 5
#
#        f.puts $spider_heal
#      }
#    end
#
#    def self.level_four_spider
#      $spider_hp   = File.read("pet_stats/spider_hp.txt").strip.to_s
#      $spider_atk  = File.read("pet_stats/spider_atk.txt").strip.to_s
#      $spider_heal = File.read("pet_stats/spider_heal.txt").strip.to_s
#
#      File.open("pet_stats/spider_hp.txt", "w") { |f|
#        $spider_hp = $spider_hp + 7
#
#        f.puts $spider_hp
#      }
#
#      File.open("pet_stats/spider_atk.txt", "w") { |f|
#        $spider_atk = $spider_atk + 7
#
#        f.puts $spider_atk
#      }
#
#      File.open("pet_stats/spider_heal.txt", "w") { |f|
#        $spider_heal = $spider_heal + 7
#
#        f.puts $spider_heal
#      }
#    end
#
#    def self.level_five_spider
#      $spider_hp   = File.read("pet_stats/spider_hp.txt").strip.to_s
#      $spider_atk  = File.read("pet_stats/spider_atk.txt").strip.to_s
#      $spider_heal = File.read("pet_stats/spider_heal.txt").strip.to_s
#
#      File.open("pet_stats/spider_hp.txt", "w") { |f|
#        $spider_hp = $spider_hp + 9
#
#        f.puts $spider_hp
#      }
#
#      File.open("pet_stats/spider_atk.txt", "w") { |f|
#        $spider_atk = $spider_atk + 9
#
#        f.puts $spider_atk
#      }
#
#      File.open("pet_stats/spider_heal.txt", "w") { |f|
#        $spider_heal = $spider_heal + 9
#
#        f.puts $spider_heal
#      }
#    end
#
#    def self.level_six_spider
#      $spider_hp   = File.read("pet_stats/spider_hp.txt").strip.to_s
#      $spider_atk  = File.read("pet_stats/spider_atk.txt").strip.to_s
#      $spider_heal = File.read("pet_stats/spider_heal.txt").strip.to_s
#
#      File.open("pet_stats/spider_hp.txt", "w") { |f|
#        $spider_hp = $spider_hp + 11
#
#        f.puts $spider_hp
#      }
#
#      File.open("pet_stats/spider_atk.txt", "w") { |f|
#        $spider_atk = $spider_atk + 11
#
#        f.puts $spider_atk
#      }
#
#      File.open("pet_stats/spider_heal.txt", "w") { |f|
#        $spider_heal = $spider_heal + 11
#
#        f.puts $spider_heal
#      }
#    end
#
#    def self.level_seven_spider
#      $spider_hp   = File.read("pet_stats/spider_hp.txt").strip.to_s
#      $spider_atk  = File.read("pet_stats/spider_atk.txt").strip.to_s
#      $spider_heal = File.read("pet_stats/spider_heal.txt").strip.to_s
#
#      File.open("pet_stats/spider_hp.txt", "w") { |f|
#        $spider_hp = $spider_hp + 13
#
#        f.puts $spider_hp
#      }
#
#      File.open("pet_stats/spider_atk.txt", "w") { |f|
#        $spider_atk = $spider_atk + 13
#
#        f.puts $spider_atk
#      }
#
#      File.open("pet_stats/spider_heal.txt", "w") { |f|
#        $spider_heal = $spider_heal + 13
#
#        f.puts $spider_heal
#      }
#    end
#
#    #####################################################################################################
#    #                                Main Pet Spider Functionality                                      #
#    #####################################################################################################
#    def self.enemy_spotted
#      # Determines if your pet spider pig has seen the enemy.
#      enemy_event         = File.readlines("enemies/enemies_spotted/spot_enemy.txt")
#      enemy_event_toggle = File.read("enemies/enemies_toggle/toggle_enemies.txt").strip.to_i
#      enemy_spotted       = enemy_event[enemy_event_toggle]
#
#      if enemy_spotted == true
#        $enemy_hp = $enemy_hp - $spider_atk
#
#        puts ">> Your pet spider pig spotted #{enemy_spotted}, and was attacked by your pet spider pig..."
#      else
#        puts ">> Your pet spider pig hasn't spotted the enemy..."
#      end
#    end
#
#    # A list of all possible nevigations, behaviours, and noises.
#    #def self.navigation
#    #  navigation_x = File.readlines("lifeform/aspects/navigation_x.txt")
#    #  navigation_y = File.readlines("lifeform/aspects/navigation_y.txt")
#    #
#    #  navigational_ai = File.read("ainput/navigation/input.txt")
#    #
#    #  if navigation_x[navigational_ai_x] == player_x and navigation_y[navigational_ai_y] == player_y
#    #    puts ">> Your pet spider pig moved in the direction of your player for ear scratches."
#    #
#    #    enemy_spotted
#    #  else
#    #    puts ">> Your pet spider pig stays where its at sitting on its eight legs..."
#    #  end
#    #end
#
#    def self.behaviours
#      behaviours    = File.readlines("lifeform/aspects/behaviours.txt")
#      behaviours_ai = File.read("ainput/behaviours/input.txt").strip.to_i
#
#      current_behavours = behaviours[behaviours_ai]
#
#      if    current_behaviours ==      "Spins spidersilk..."
#        puts ">> Your pet spider pig spins some spidersilk..."
#      elsif current_behaviours ==       "Bites the player..."
#        puts ">> Your pet spider bites the player affectionately..."
#
#        sleep(1.5)
#
#        system("ruby rockpaperzombie.rb")
#      end
#    end
#
#    def self.pet_noises
#      noises          = File.readlines("lifeform/aspects/noises.txt")
#      noises_ai       = File.read("ainput/noises/input.txt").strip.to_i
#      current_noises  = noises[noises_ai]
#
#      elsif current_noises == "Hisses like a spider..."
#        puts ">> Your pet spider pig hisses like a spider..."
#      elsif current_noises == "Oinks like a baby pig..."
#        puts ">> Your pet spider pig oinks like a baby pig..."
#      end
#    end
#
#    def self.spider_damage_formula
#      #Switch to routine determine damage rate.
#      healing_accuracy = {
#        "enemy"        => "gribatomaton",
#        "gribatomaton" =>       "player",
#        "player"       =>        "enemy",
#      }
#
#      @cchoice_healing_options = [  "enemy", "gribatomaton", "player" ]
#
#      @landed_choice = @cchoice_healing_options.sample
#
#      if    @cchoice_chosen_healing ==        "enemy"; # Enemy damages the spider.
#        # Enemy launches its counter attack.
#      elsif @cchoice_chosen_healing == "gribatomaton"; # Spider damages the enemy.
#        # Spider successfully damages the enemy.
#      elsif @cchoice_chosen_healing ==       "player"; # Enemy damages the plauer.
#        # Player counter attacks the enemy.
#      end
#    end
#
#    def self.enemy_damage_formula
#      #Switch to routine determine damage rate.
#
#      @cchoice_healing_options = [  "enemy", "gribatomaton", "player" ]
#
#      @landed_choice = @cchoice_healing_options.sample
#
#      if    @cchoice_chosen_healing ==        "enemy"; # Enemy is damaged by the spider.
#        # Counterattack for spider.
#      elsif @cchoice_chosen_healing == "gribatomaton"; # Spider is damaged the enemy.
#        # Enemey successfully damages the spider.
#      elsif @cchoice_chosen_healing ==       "player"; # Enemy is damaged by the player...
#        # Counterattack by the player.
#      end
#    end
#
#    def self.spider_pig_farmer
#      monster_form = {
#        "spider" =>    "pig",
#        "pig"    => "farmer",
#        "farmer" => "spider",
#      }
#
#      print "[ Spider, Pig, Farmer ] >> "
#      @spider_choices = ["spider", "pig", "farmer"]
#      @choice = @spider_choices.sample
#
#      @cchoices = ["spider", "pig", "farmer"]
#      @cchoice  = @cchoices.sample
#
#      if    monster_form[@cchoice] == @choice
#        puts "Spider managed to prevent enemy from harming the player."
#
#        spider_damage_formula
#      elsif monster_form[@choice]  == @choice # Spider prevents attacking of player altogether.
#        puts "Spider managed to prevent enemy from harming the player."
#
#        sleep(1.5)
#      elsif @choice == @cchoice
#        enemy_damage_formula
#      else
#        puts "Process was not understood..."
#      end
#    end
#  end
#end

module YumemoireSpatialRelationships
  class Error < StandardError; end

  class Static_Perimeters

    # The objects within the space.
    def self.positive_perimeters
      # Base radius of static objects.
      base_radius   = 2500
    
      # Specfic multipliers for Earth index based objects.
      base_two =  2   
      base_fro =  4
      base_six =  6
      base_eit =  8
  
      # Size of specific objects.
      size_of_planets    = base_radius ** base_fro
      size_of_moons      = base_radius ** base_two
      size_of_stars      = base_radius ** base_six
      size_of_blackholes = base_radius ** base_eit
    
      # Total output sizes of specific objects.
      puts "The size of the planets is #{size_of_planets} radius."; sleep(3)
      puts "The size of the moons is #{size_of_moons} radius."; sleep(3)
      puts "The size of the stars is #{size_of_stars} radius."; sleep(3)
      puts "The size of a blackhole is #{size_of_blackholes} radius."; sleep(3)
    end
  
    # Space between the objects.
    def self.negative_perimeters
      # Base distance between objects.
      base_distance = 1_000_000_000
  
      # Estimated divider between specific objects to base distance.
      space_between_planets    = 43.8
      space_between_moons      = 14.6
      space_between_stars      = 876
      space_between_blackholes = 2628
    
      # Minimum distance between objects.
      planet_distance    = base_distance / space_between_planets
      moon_distance      = base_distance / space_between_moons
      star_distance      = base_distance / space_between_stars
      blackhole_distance = base_distance / space_between_blackholes
    
      # Actual distance between objects
      actual_planets    = planet_distance * 10
      actual_moons      = moon_distance * 10
      actual_stars      = star_distance * 10
      actual_blackholes = blackhole_distance * 10
    
      # The output results of distance between objects.
      puts "The distance between planets is #{actual_planets} miles."; sleep(3)
      puts "The distance between moons is #{actual_moons} miles."; sleep(3)
      puts "The distance between stars is #{actual_stars} miles."; sleep(3)
      puts "The distance between blackholes is #{actual_blackholes} miles."; sleep(3)
    end
  
  end

  # Changing perimeters
  class Dynamic_Perimeters

    # The objects within the space.
    def self.positive_perimeters
      spaceship     = File.read("_data/dynamic/positive_perimeters/spaceship_size.txt").strip.to_i
      space_station = spaceship * 200
      satalite      = space_station / 10
    
      puts "The total size of the space shuttle is #{spaceship} feet."; sleep(3)
      puts "The total size of the space station is #{space_station} feet."; sleep(3)
      puts "The total size of the satalite is #{satalite} feet."; sleep(3)
    end
  
    # Space between the objects.
    def self.negative_perimeters
      base_multiplier = 10
  
      # Minimum space between objects.
      space_between_spaceships = File.read("_data/dynamic/negative_perimeters/space_between_spaceships.txt").strip.to_i
      space_between_station    = File.read("_data/dynamic/negative_perimeters/space_between_station.txt").strip.to_i
      space_between_satalite   = File.read("_data/dynamic/negative_perimeters/space_between_satalite.txt").strip.to_i
    
      # Actual space between objects
      actual_spaceship_distance = space_between_spaceships * base_multiplier
      actual_station_distance   = space_between_station * base_multiplier
      actual_satalite_distance  = space_between_satalite * base_multiplier
    
      puts "The minimum space between shuttles is #{actual_spaceship_distance} feet."; sleep(3)
      puts "The minimum space between stations is #{actual_station_distance} feet."; sleep(3)
      puts "The minimum space between satalites is #{actual_satalite_distance} feet."; sleep(3)
    end

  end

  class SpatialEvaluator
    def self.evaluate_body
      require "naive_bayes"

      spatial = NaiveBayes.new(:planet_radius,
                               :moon_radius,
                               :star_radius,
                               :blackhole_radius,
                               :distance_between_planets,
                               :distance_between_moons,
                               :distance_between_stars,
                               :distance_between_blackholes,
                               :spaceshuttle_size,
                               :spacestation_size,
                               :size_of_satalight,
                               :minimum_space_between_shuttles,
                               :minimum_space_between_stations,
                               :minimum_space_between_satalights,
      )
 
      spatial.train(:planet_radius,                          "The size of the planets is 39062500000000 radius.", "word")
      spatial.train(:moon_radius,                                     "The size of the moons is 6250000 radius.", "word")
      spatial.train(:star_radius,                       "The size of the stars is 244140625000000000000 radius.", "word")
      spatial.train(:blackhole_radius,         "The size of a blackhole is 1525878906250000000000000000 radius.", "word")
      spatial.train(:distance_between_planets,       "The distance between planets is 228310502.28310502 miles.", "word")
      spatial.train(:distance_between_moons,             "The distance between moons is 684931506.849315 miles.", "word")
      spatial.train(:distance_between_stars,                     "The distance between stars is 11415520 miles.", "word")
      spatial.train(:distance_between_blackholes,            "The distance between blackholes is 3805170 miles.", "word")
      spatial.train(:spaceshuttle_size,                         "The total size of the space shuttle is 5 feet.", "word")
      spatial.train(:spacestation_size,                      "The total size of the space station is 1000 feet.", "word")
      spatial.train(:size_of_satalight,                            "The total size of the satalite is 100 feet.", "word")
      spatial.train(:minimum_space_between_shuttles,            "The minimum space between shuttles is 50 feet.", "word")
      spatial.train(:minimum_space_between_stations,            "The minimum space between stations is 50 feet.", "word")
      spatial.train(:minimum_space_between_satalights,         "The minimum space between satalites is 50 feet.", "word")
  
      spatial_relationships = File.readlines("_input/relationships.txt")

      size_limit = spatial_relationships.size.to_i

      index = 0

      size_limit.times do
        classification = spatial.classify(spatial_relationships[index].strip.to_s)
        
        print classification
        puts " "

        index = index + 1
      end
    end

  end
end

module YumemoireBezerkerMode

  class BezerkerMode
    ###############################################################################################
    #                                   AI Decision Making                                        #
    ###############################################################################################
    def self.ai_decision
      cchoice = @choice

      ## Determining user data and user choice.
      value = File.read("lib/input/user/user_choice.txt").to_s.to_i

      user_data   = File.readlines("lib/data/user/candidates.txt")
      user_choice = user_data[value]

      ## Processing AI focused data
      ai_choice            = File.read("lib/data/ai/ai_choice.txt").to_s.to_i
      ai_initial_candidate = user_data[ai_choice]
      ai_search_limit      = user_data.size.to_i

      ## Create AI data from user data.
      ai_search_limit.times do
        if ai_choice == user_choice
          #puts "\e[38;2;187;127;118m  The specific candidate was found. Terminating selection..."

          ai_data      = user_data.slice!(ai_choice)

          open("lib/data/ai/candidates.txt", "w") { |f|
            f.puts ai_data
          }
        else
          puts "\e[38;2;187;127;118mL'ennemi découvre que vous n'avez pas fait ce choix...\e[0m"
        end

        sleep(1.5)
      end

      ## AI processing data.
      ai_choice            = File.read("lib/data/ai/ai_choice.txt").to_s.to_i
      ai_data              = File.readlines("lib/data/ai/candidates.txt")
      ai_search_limit      = ai_data.size.to_i
      ai_next_candidate    = ai_data[ai_choice]

      ai_search_limit.times do
        if ai_next_candidate == user_choice
          ai_final_candidate = ai_next_candidate
    
          puts "\e[38;2;187;127;118mCandidate found, processing input...\e[0m"; sleep(1)

          # Breaks the loop if an appropriate candidate is found.

          sleep(1.5)

          conditions = ["Sword", "Stone", "Tarp"]

          decision_made = conditions.sample

          puts "\e[38;2;187;127;118mBy process of elimination, the bot chose: #{ai_data}\e[0m"

          @cchoice = "#{ai_data}"

          puts $cchoice

          break
        else
          ai_choice            = File.read("lib/data/ai/ai_choice.txt").to_s.to_i
          ai_data              = File.readlines("lib/data/ai/candidates.txt")
          ai_search_limit      = ai_data.size.to_i
          ai_next_candidate    = ai_data[ai_choice]

          ai_data      = user_data.slice!(ai_choice).strip

          puts "\e[38;2;187;127;118mEnemy found the option #{ai_data}\e[0m"

          enemy_decision = ["choose", "skip"]

          decision_made = enemy_decision.sample

          if decision_made == "choose"
            puts "\e[38;2;187;127;118mThe enemy chose: #{ai_data}, but found it causes a stalemate. Makes a new decision\e[0m"

            @cchoice = "#{ai_data}"

            enemy_decision = ["Epee", "Ishi", "Bache"]

            decision_made = enemy_decision.sample

            if    decision_made == "Sword"
              @cchoice = "Epee"
            elsif decision_made == "Stone"
              @cchoice = "Ishi"
            elsif decision_made ==  "Tarp"
              @cchoice = "Bache"
            end

            break
          else
            puts "\e[38;2;187;127;118mEnemy weighed the option of choosing #{ai_data}, but decided to skip its turn.\e[0m"

            break
          end

          sleep(1.5)
 
          open("lib/data/ai/candidates.txt", "w") { |f|
            f.puts ai_data
          }
        end
      end
    end

    #############################################################################################
    # Standard methods for player autonomy in the game.                                         #
    #############################################################################################
    def self.full_player_control
      #player_heal = $healing_rate

      # Loop for full player control

      # Least damaging, yet most efficient healing and other maintence.

      conditions = {
        "Epee"  => "Ishi",
        "Ishi"  => "Bache",
        "Bache" => "Epee",
      }

      bezerker_chance = ["autonomy", "autonomy", "autonomy", "autonomy"]

      chance_of_bezerker = bezerker_chance.sample

      if chance_of_bezerker == "autonomy"
        print "Player Choice >> "; @choice = gets.chomp
      else
        puts "Player lost control of the MC..."

        sleep(1.5)

        @choice = File.readlines("lib/data/ai/player_patterns/observed_player_actions.txt").sample.strip.to_s
      end

      @cchoice  = File.readlines("lib/data/ai/enemy_patterns/observed_enemy_actions.txt").sample.strip.to_s

      puts "The enemy chose: #{@cchoice}"

      if    @choice == "Epee"
        File.open("lib/input/user/user_choice.txt", "w") { |f|
          f.puts "0"
        }

        # Records a history of player actions.
        File.open("lib/data/user/chosen_action.txt", "a") { |f|
          f.puts "0"
        }

        # Allows enemey to learn about player patterns.
        File.open("lib/data/ai/player_patterns/observed_player_actions.txt", "a") { |f|
          f.puts "Epee"
        }
      elsif @choice == "Ishi"
        File.open("lib/input/user/user_choice.txt", "w") { |f|
          f.puts "1"
        }

        # Records a history of player actions.
        File.open("lib/data/user/chosen_action.txt", "a") { |f|
          f.puts "1"
        }

        # Allows enemey to learn about player patterns.
        File.open("lib/data/ai/player_patterns/observed_player_actions.txt", "a") { |f|
          f.puts "Ishi"
        }
      elsif @choice == "Bache"
        File.open("lib/input/user/user_choice.txt", "w") { |f|
          f.puts "2"
        }

        # Records a history of player actions.
        File.open("lib/data/user/chosen_action.txt", "a") { |f|
          f.puts "2"
        }

        # Allows enemey to learn about player patterns.
        File.open("lib/data/ai/player_patterns/observed_player_actions.txt", "a") { |f|
          f.puts "Bache"
        }
      elsif @choice == "Sleep"
        File.open("lib/input/user/user_choice.txt", "w") { |f|
          f.puts "2"
        }

        # Records a history of player actions. This one defaults to bache even though its a distinct action.
        open("lib/data/user/chosen_action.txt", "a") { |f|
          f.puts "2"
        }

        # Allows enemey to learn about player patterns.
        File.open("lib/data/ai/player_patterns/observed_player_actions.txt", "a") { |f|
          f.puts "Bache"
        }
      end

      puts " "
      sleep(1.5)

      # Experiment with using an enemy that learns from player's decisions.'
      YumemoireFramework::BezerkerMode.ai_decision

      if conditions[@choice] == @cchoice
        puts "You were struck by the enemy!"

        $player_struck = $player_struck + 1

        # The amount of damage player gets is based on the enemies attack power.
        #$player_hp = $player_hp - $enemy_atk
        enemy_damage_rate
      elsif @cchoice == @choice
        puts "You reach a stalemate."

        $stalemates = $stalemates + 1
      elsif conditions[@cchoice] == @choice
        puts "You struck the enemy!"

        $enemy_struck = $enemy_struck + 1

        # The amount of damage enemy recieves is based on the player's attack power.
        #$enemy_hp = $enemy_hp - $player_atk
        player_damage_rate
      elsif @choice == "Sleep"
        puts "\e[38;2;187;127;118mYou've opted to stay at an inn...'\e[0m"

        sleep(1.5)

        YumemoireVillager::Marketplace.stay_at_inn
      else
        puts "\e[38;2;187;127;118m#{@choice} is not a valid option\e[0m"
      end

      observe_enemy
      observe_player

      sleep(1.5)

      $current_day = $current_day + 1
    end

    def self.mostly_player_control
      #player_heal = $healing_rate

      # Loop for mostly player control

      # More powerful than full player control, but less efficient maintanence tasks.

      conditions = {
        "Epee"  => "Ishi",
        "Ishi"  => "Bache",
        "Bache" => "Epee",
      }

      bezerker_chance = ["autonomy", "autonomy", "autonomy", "bezerker"]

      chance_of_bezerker = bezerker_chance.sample

      if chance_of_bezerker == "autonomy"
        print "Player Choice >> "; @choice = gets.chomp
      else
        puts "Player lost control of the MC..."

        sleep(1.5)

        @choice = File.readlines("lib/data/ai/player_patterns/observed_player_actions.txt").sample.strip.to_s
      end

      @cchoice  = File.readlines("lib/data/ai/enemy_patterns/observed_enemy_actions.txt").sample.strip.to_s

      puts "The enemy chose: #{@cchoice}"

      if    @choice == "Epee"
        File.open("lib/input/user/user_choice.txt", "w") { |f|
          f.puts "0"
        }

        # Records a history of player actions.
        File.open("lib/data/user/chosen_action.txt", "a") { |f|
          f.puts "0"
        }

        # Allows enemey to learn about player patterns.
        File.open("lib/data/ai/player_patterns/observed_player_actions.txt", "a") { |f|
          f.puts "Epee"
        }
      elsif @choice == "Ishi"
        File.open("lib/input/user/user_choice.txt", "w") { |f|
          f.puts "1"
        }

        # Records a history of player actions.
        File.open("lib/data/user/chosen_action.txt", "a") { |f|
          f.puts "1"
        }

        # Allows enemey to learn about player patterns.
        File.open("lib/data/ai/player_patterns/observed_player_actions.txt", "a") { |f|
          f.puts "Ishi"
        }
      elsif @choice == "Bache"
        File.open("lib/input/user/user_choice.txt", "w") { |f|
          f.puts "2"
        }

        # Records a history of player actions.
        File.open("lib/data/user/chosen_action.txt", "a") { |f|
          f.puts "2"
        }

        # Allows enemey to learn about player patterns.
        File.open("lib/data/ai/player_patterns/observed_player_actions.txt", "a") { |f|
          f.puts "Bache"
        }
      elsif @choice == "Sleep"
        File.open("lib/input/user/user_choice.txt", "w") { |f|
          f.puts "2"
        }

        # Records a history of player actions. This one defaults to bache even though its a distinct action.
        File.open("lib/data/user/chosen_action.txt", "a") { |f|
          f.puts "2"
        }

        # Allows enemey to learn about player patterns.
        File.open("lib/data/ai/player_patterns/observed_player_actions.txt", "a") { |f|
          f.puts "Bache"
        }
      end

      puts " "
      sleep(1.5)

      # Experiment with using an enemy that learns from player's decisions.'
      YumemoireFramework::BezerkerMode.ai_decision

      if conditions[@choice] == @cchoice
        puts "You were struck by the enemy!"

        $player_struck = $player_struck + 1

        # The amount of damage player gets is based on the enemies attack power.
        #$player_hp = $player_hp - $enemy_atk
        YumemoireDamage::DamageFormulas.enemy_damage_rate
      elsif @cchoice == @choice
        puts "You reach a stalemate."

        $stalemates = $stalemates + 1
      elsif conditions[@cchoice] == @choice
        puts "You struck the enemy!"

        $enemy_struck = $enemy_struck + 1

        # The amount of damage enemy recieves is based on the player's attack power.
        #$enemy_hp = $enemy_hp - $player_atk
        YumemoireDamage::DamageFormulas.player_damage_rate
      elsif @choice == "Sleep"
        puts "\e[38;2;187;127;118mYou've opted to stay at an inn...'\e[0m"

        sleep(1.5)

        YumemoireVillager::Marketplace.stay_at_inn
      else
        puts "\e[38;2;187;127;118m#{@choice} is not a valid option\e[0m"
      end

      observe_enemy
      observe_player

      sleep(1.5)

      $current_day = $current_day + 1
    end

    ### This section flips between automatic player and player autonomy.
    def self.mostly_automated_player
      #player_heal = $healing_rate

      # Loop for mostly automated player.

      # The most powerful attacks for player character, but least efficient maintance tasks.

      conditions = {
        "Epee"  => "Ishi",
        "Ishi"  => "Bache",
        "Bache" => "Epee",
      }

      bezerker_chance = ["autonomy", "bezerker", "bezerker", "bezerker"]

      chance_of_bezerker = bezerker_chance.sample

      if chance_of_bezerker == "autonomy"
        print "Player Choice >> "; @choice = gets.chomp
      else
        puts "Player lost control of the MC..."

        sleep(1.5)

        @choice = File.readlines("lib/data/ai/player_patterns/observed_player_actions.txt").sample.strip.to_s
      end

      @cchoice  = File.readlines("lib/data/ai/enemy_patterns/observed_enemy_actions.txt").sample.strip.to_s

      puts "The enemy chose: #{@cchoice}"

      if    @choice == "Epee"
        File.open("lib/input/user/user_choice.txt", "w") { |f|
          f.puts "0"
        }

        # Records a history of player actions.
        File.open("lib/data/user/chosen_action.txt", "a") { |f|
          f.puts "0"
        }

        # Allows enemey to learn about player patterns.
        File.open("lib/data/ai/player_patterns/observed_player_actions.txt", "a") { |f|
          f.puts "Epee"
        }
      elsif @choice == "Ishi"
        File.open("lib/input/user/user_choice.txt", "w") { |f|
          f.puts "1"
        }

        # Records a history of player actions.
        File.open("lib/data/user/chosen_action.txt", "a") { |f|
          f.puts "1"
        }

        # Allows enemey to learn about player patterns.
        File.open("lib/data/ai/player_patterns/observed_player_actions.txt", "a") { |f|
          f.puts "Ishi"
        }
      elsif @choice == "Bache"
        File.open("lib/input/user/user_choice.txt", "w") { |f|
          f.puts "2"
        }

        # Records a history of player actions.
        File.open("lib/data/user/chosen_action.txt", "a") { |f|
          f.puts "2"
        }

        # Allows enemey to learn about player patterns.
        File.open("lib/data/ai/player_patterns/observed_player_actions.txt", "a") { |f|
          f.puts "Bache"
        }
      elsif @choice == "Sleep"
        File.open("lib/input/user/user_choice.txt", "w") { |f|
          f.puts "2"
        }

        # Records a history of player actions. This one defaults to bache even though its a distinct action.
        File.open("lib/data/user/chosen_action.txt", "a") { |f|
          f.puts "2"
        }

        # Allows enemy to learn about player patterns.
        File.open("lib/data/ai/player_patterns/observed_player_actions.txt", "a") { |f|
          f.puts "Bache"
        }
      end

      puts " "
      sleep(1.5)

      # Experiment with using an enemy that learns from player's decisions.'
      YumemoireFramework::BezerkerMode.ai_decision

      if conditions[@choice] == @cchoice
        puts "You were struck by the enemy!"

        $player_struck = $player_struck + 1

        # The amount of damage player gets is based on the enemies attack power.
        #$player_hp = $player_hp - $enemy_atk
        YumemoireDamage::DamageFormulas.enemy_damage_rate
      elsif @cchoice == @choice
        puts "You reach a stalemate."

        $stalemates = $stalemates + 1
      elsif conditions[@cchoice] == @choice
        puts "You struck the enemy!"

        $enemy_struck = $enemy_struck + 1

        # The amount of damage enemy recieves is based on the player's attack power.
        #$enemy_hp = $enemy_hp - $player_atk
        YumemoireDamage::DamageFormulas.player_damage_rate
      elsif @choice == "Sleep"
        puts "\e[38;2;187;127;118mYou've opted to stay at an inn...'\e[0m"

        sleep(1.5)

        YumemoireVillager::Marketplace.stay_at_inn
      else
        puts "\e[38;2;187;127;118m#{@choice} is not a valid option\e[0m"
      end

      observe_enemy
      observe_player

      sleep(1.5)

      $current_day = $current_day + 1
    end

    def self.fully_automated_player
      # Loop for fully automated player characters.

      # Your attacks are more powerful, but you're not as efficient at maintanence.

      guess_player_movement
      guess_enemy_movement

      conditions = {
        "Epee"  => "Ishi",
        "Ishi"  => "Bache",
        "Bache" => "Epee",
      }

      bezerker_chance = ["bezerker", "bezerker", "bezerker", "bezerker"]

      chance_of_bezerker = bezerker_chance.sample

      if chance_of_bazerker == "autonomy"
        print "Player Choice >> "; @choice = gets.chomp
      else
        puts "Player lost control of the MC..."

        sleep(1.5)

        @choice = File.readlines("lib/data/ai/player_patterns/observed_player_actions.txt").sample.strip.to_s
      end

      @cchoice  = File.readlines("lib/data/ai/enemy_patterns/observed_enemy_actions.txt").sample.strip.to_s

      puts "The enemy chose: #{@choice}"

      if    @choice == "Epee"
        File.open("lib/input/user/user_choice.txt", "w") { |f|
          f.puts "0"
        }

        # Records a history of player actions.
        File.open("lib/data/user/chosen_action.txt", "a") { |f|
          f.puts "0"
        }
      elsif @choice == "Ishi"
        File.open("lib/input/user/user_choice.txt", "w") { |f|
          f.puts "1"
        }

        # Records a history of player actions.
        File.open("lib/data/user/chosen_action.txt", "a") { |f|
          f.puts "1"
        }
      elsif @choice == "Bache"
        File.open("lib/input/user/user_choice.txt", "w") { |f|
          f.puts "2"
        }

        # Records a history of player actions.
        File.open("lib/data/user/chosen_action.txt", "a") { |f|
          f.puts "2"
        }
      elsif @choice == "Sleep"
        File.open("lib/input/user/user_choice.txt", "w") { |f|
          f.puts "2"
        }

        # Records a history of player actions. This one defaults to bache even though its a distinct action.
        File.open("lib/data/user/chosen_action.txt", "a") { |f|
          f.puts "2"
        }
      end

      puts " "
      sleep(1.5)

      # Experiment with using an enemy that learns from player's decisions.'
      YumemoireFramework::BezerkerMode.ai_decision

      if conditions[@choice] == @cchoice
        puts "You were struck by the enemy!"

        $player_struck = $player_struck + 1

        # The amount of damage player gets is based on the enemies attack power.
        #$player_hp = $player_hp - $enemy_atk
        YumemoireDamage::DamageFormulas.enemy_damage_rate
      elsif @cchoice == @choice
        puts "You reach a stalemate."

        $stalemates = $stalemates + 1
      elsif conditions[@cchoice] == @choice
        puts "You struck the enemy!"

        $enemy_struck = $enemy_struck + 1

        # The amount of damage enemy recieves is based on the player's attack power.
        #$enemy_hp = $enemy_hp - $player_atk
        YumemoireDamage::DamageFormulas.player_damage_rate
      elsif @choice == "Sleep"
        puts "\e[38;2;187;127;118mYou've opted to stay at an inn...'\e[0m"

        sleep(1.5)

        YumemoireVillager::Marketplace.stay_at_inn
      else
        puts "\e[38;2;187;127;118m#{@choice} is not a valid option\e[0m"
      end

      #$current_day = $current_day + 1

      sleep(1.5)

      $current_day = $current_day + 1
    end

    def self.pdm_metric
      ####################################################################################################
      #                                  Game Loop Chooser Coming Soon                                   #
      ####################################################################################################
      pdm = $personal_demon_metric # File.read("lib/data/user/personal_demon_metric.txt").strip.to_i

      gets.chomp

      loop do
        if pdm > 100
          pdm = 0

          File.open("lib/data/user/personal_demon_metric.txt", "w") { |f|
            f.puts pdm
          }
        end

        system("clear")

        if $current_day < $lunar_ticks
          this_day = 29

          puts "\e[38;2;187;127;118mLa prochaine phase lunaire est en cours: #{this_day - $current_day} days...\e[0m"
        else
          lunar_cycle

          # Reset lunar ticks to twenty days away.
          $current_day = 1
        end

        puts "\e[38;2;187;127;118m[ Currency is #{$player_franc} Francs And #{$player_yen} Yen ]\e[0m"

        if $wooden_shoes == true
          puts "[ Clog Studiness: #{$clog_sturdiness} ]"
        else
          puts "[ Clog Studiness: Inactive ]"
        end

        puts "\e[38;2;187;127;118m\n[ Stalemates: #{$stalemates} ] [ Player Strikes: #{$player_struck} ] [ Enemy Strikes: #{$enemy_struck} ]\e[0m"
        puts "\e[38;2;187;127;118m  [ #{$player_lunario} Lunario ( You wont need this for most game functions. ) ]"

        puts "Personal Demon Metric: #{pdm}"

        puts "\e[38;2;187;127;118m\n\e[0m"
        puts "\e[38;2;187;127;118mSouer De Chaos ( Ana Nuveyatusuki ) HP: #{$player_hp} \e[0m"
        puts "\e[38;2;187;127;118mSouer De Commande ( Ana Nuveyatusuki ) HP: #{$enemy_hp}\e[0m"
        puts "\e[38;2;187;127;118m\n\e[0m"

        if pdm == 0
          #$healing_rate = 8

          File.open("lib/data/user/personal_demon_metric.txt", "w") { |f|
            pdm = pdm + 25

            f.puts pdm
          }

          YumemoireFramework::BezerkerMode.full_player_control
        elsif pdm >= 25
          #$healing_rate = 6

          File.open("lib/data/user/personal_demon_metric.txt", "w") { |f|
            pdm = pdm + 25

            f.puts pdm
          }

          YumemoireFramework::BezerkerMode.mostly_player_control
        elsif pdm >= 50
          #$healing_rate = 6

          File.open("lib/data/user/personal_demon_metric.txt", "w") { |f|
            pdm = pdm + 25

            f.puts pdm
          }

          YumemoireFramework::BezerkerMode.mostly_player_control
        elsif pdm >= 75
          #$healing_rate = 4

          File.open("lib/data/user/personal_demon_metric.txt", "w") { |f|
            pdm = pdm + 25

            f.puts pdm
          }

          YumemoireFramework::BezerkerMode.mostly_automated_player
        elsif pdm >= 100
          #$healing_rate = 2

          YumemoireFramework::BezerkerMode.fully_automated_player # With full personal demon metric meaning automated beserker like mode.
        end

      end
    end
  end

end

module YumemoireZombieMode
  class ZombieMode
    ###############################################################################################
    #                                   AI Decision Making                                        #
    ###############################################################################################
    def self.ai_decision
      cchoice = @choice

      ## Determining user data and user choice.
      value = File.read("lib/input/user/user_choice.txt").to_s.to_i

      user_data   = File.readlines("lib/data/user/candidates.txt")
      user_choice = user_data[value]

      ## Processing AI focused data
      ai_choice            = File.read("lib/data/ai/ai_choice.txt").to_s.to_i
      ai_initial_candidate = user_data[ai_choice]
      ai_search_limit      = user_data.size.to_i

      ## Create AI data from user data.
      ai_search_limit.times do
        if ai_choice == user_choice
          #puts "\e[38;2;187;127;118m  The specific candidate was found. Terminating selection..."

          ai_data      = user_data.slice!(ai_choice)

          open("lib/data/ai/candidates.txt", "w") { |f|
            f.puts ai_data
          }
        else
          puts "\e[38;2;187;127;118mL'ennemi découvre que vous n'avez pas fait ce choix...\e[0m"
        end

        sleep(1.5)
      end

      ## AI processing data.
      ai_choice            = File.read("lib/data/ai/ai_choice.txt").to_s.to_i
      ai_data              = File.readlines("lib/data/ai/candidates.txt")
      ai_search_limit      = ai_data.size.to_i
      ai_next_candidate    = ai_data[ai_choice]

      ai_search_limit.times do
        if ai_next_candidate == user_choice
          ai_final_candidate = ai_next_candidate
    
          puts "\e[38;2;187;127;118mCandidate found, processing input...\e[0m"; sleep(1)

          # Breaks the loop if an appropriate candidate is found.

          sleep(1.5)

          conditions = ["Sword", "Stone", "Tarp"]

          decision_made = conditions.sample

          puts "\e[38;2;187;127;118mBy process of elimination, the bot chose: #{ai_data}\e[0m"

          @cchoice = "#{ai_data}"

          puts $cchoice

          break
        else
          ai_choice            = File.read("lib/data/ai/ai_choice.txt").to_s.to_i
          ai_data              = File.readlines("lib/data/ai/candidates.txt")
          ai_search_limit      = ai_data.size.to_i
          ai_next_candidate    = ai_data[ai_choice]

          ai_data      = user_data.slice!(ai_choice).strip

          puts "\e[38;2;187;127;118mEnemy found the option #{ai_data}\e[0m"

          enemy_decision = ["choose", "skip"]

          decision_made = enemy_decision.sample

          if decision_made == "choose"
            puts "\e[38;2;187;127;118mThe enemy chose: #{ai_data}, but found it causes a stalemate. Makes a new decision\e[0m"

            @cchoice = "#{ai_data}"

            enemy_decision = ["Epee", "Ishi", "Bache"]

            decision_made = enemy_decision.sample

            if    decision_made == "Sword"
              @cchoice = "Epee"
            elsif decision_made == "Stone"
              @cchoice = "Ishi"
            elsif decision_made ==  "Tarp"
              @cchoice = "Bache"
            end

            break
          else
            puts "\e[38;2;187;127;118mEnemy weighed the option of choosing #{ai_data}, but decided to skip its turn.\e[0m"

            break
          end

          sleep(1.5)
 
          open("lib/data/ai/candidates.txt", "w") { |f|
            f.puts ai_data
          }
        end
      end

      def self.parser
        loop do
          system("clear")

          if $current_day < $lunar_ticks
            this_day = 29

            puts "\e[38;2;187;127;118mLa prochaine phase lunaire est en cours: #{this_day - $current_day} days...\e[0m"
          else
            lunar_cycle

            # Reset lunar ticks to twenty days away.
            $current_day = 1
          end

          puts "\e[38;2;187;127;118m[ Currency is #{$player_franc} Francs And #{$player_yen} Yen ]\e[0m"

          puts "\e[38;2;187;127;118m\n[ Stalemates: #{$stalemates} ] [ Player Strikes: #{$player_struck} ] [ Enemy Strikes: #{$enemy_struck} ]\e[0m"
          puts "\e[38;2;187;127;118m  [ #{$player_lunario} Lunario ( You wont need this for most game functions. ) ]"

          puts "\e[38;2;187;127;118m\n\e[0m"
          puts "\e[38;2;187;127;118mSouer De Chaos ( Ana Nuveyatusuki ) HP: #{$player_hp} \e[0m"
          puts "\e[38;2;187;127;118mSouer De Commande ( Ana Nuveyatusuki ) HP: #{$enemy_hp}\e[0m"
          puts "\e[38;2;187;127;118m\n\e[0m"

          if $player_hp > 0
            system("clear")

            puts "\e[38;2;187;127;118mYou've been zombiefied!\e[0m"

            sleep(1.5)

            system("ruby rockpaper.rb")
          elsif $enemy_hp <= 0
            puts "\e[38;2;187;127;118mYou won\e[0m"

            gets.chomp

            abort
          end

          conditions = {
            "Epee"  =>  "Ishi",
            "Ishi"  => "Bache",
            "Bache" =>  "Epee",
          }

          puts "\e[38;2;187;127;118mTo heal the player, type: Chomp\e[0m"

          print "\e[38;2;164;145;91m\nEpee, Ishi, or Bache >> \e[0m"
          @choice = gets.chomp.capitalize

          if    @choice == "Epee"
            open("lib/input/user/user_choice.txt", "w") { |f|
              f.puts "0"
            }
          elsif @choice == "Ishi"
            open("lib/input/user/user_choice.txt", "w") { |f|
              f.puts "1"
            }
          elsif @choice == "Bache"
            open("lib/input/user/user_choice.txt", "w") { |f|
              f.puts "2"
            }
          elsif @choice == "Chomp"
            open("lib/input/user/user_choice.txt", "w") { |f|
              f.puts "2"
            }
          end

          puts " "
          sleep(1.5)

          # Experiment with using an enemy that learns from player's decisions.'
          YumemoireFramework::ZombieMode.ai_decision

          if conditions[@choice] == @cchoice
            #puts "\e[38;2;187;127;118m  You were struck by the enemy!"

            $enemy_struck = $enemy_struck + 1

            # The amount of damage player gets is based on the enemies attack power.
            #$player_hp = $player_hp - $enemy_atk
            YumemoireDamage::DamageFormulas.enemy_damage_rate
          elsif @cchoice == @choice
            puts "\e[38;2;187;127;118mYou reach a stalemate.\e[0m"

            $stalemates = $stalemates + 1
          elsif conditions[@cchoice] == @choice
            #puts "\e[38;2;187;127;118m  You struck the enemy!"

            $player_struck = $player_struck + 1

            # The amount of damage enemy recieves is based on the player's attack power.
            #$enemy_hp = $enemy_hp - $player_atk
            YumemoireDamage::DamageFormulas.player_damage_rate
          elsif @choice == "Chomp"
            puts "\e[38;2;187;127;118mYou tried staying at an inn, but hotels don't take the undead...'\e[0m"

            sleep(1.5)

            YumemoireFramework::ZombieMode.consumption
          else
            puts "\e[38;2;187;127;118m#{@choice} is not a valid option\e[0m"
          end

          $current_day = $current_day + 1
        end
      end
    end

    ###############################################################################################
    #                                 Zombie State Minigame                                       #
    ###############################################################################################
    #$true_reset_hp = File.read("lib/player_stats/true_reset_hp.txt").strip.to_i
    $reset_hp      = File.read("lib/player_stats/reset_hp.txt").strip.to_i
    $player_hp     = File.read("lib/player_stats/zombie_player_hp.txt").strip.to_i

    def self.reset_standard_hp_restoration
      puts "The curse of being a zombie has been lifted. You can not die like any other mortal."

      $reset_hp = $true_reset_hp
    end

    def self.cremation
      puts "You've self cremated."

      sleep(1.5)

      puts "You've opted to self cremate. Restarting the map."

      $player_hp = $reset_hp

      puts "Now returning to human form..."

      system("ruby rockpaper.rb")
    end

    def self.consumption
      puts "You've eaten parts of your own corpse."

      sleep(1.5)

      $reset_hp  = $reset_hp - 1
      $player_hp = $reset_hp

      print "Your HP was replinished but "

      puts " you lost 3 hit points from consuming your own body."

      File.open("lib/player_stats/zombie_player_hp.txt", "w") { |f|
        $player_hp = $player_hp + 3

        f.puts $player_hp -20
      }

      File.open("lib/player_stats/reset_hp.txt", "w") { |f|
        $reset_hp = $reset_hp - 3

        f.puts $reset_hp
      }

      system("ruby rock_paper_zombie.rb")
    end

    def self.final_wishes
      print "Do you wish to self-cremate or continue this battle? ( cremate / consumption ) << "

      choose_your_fate = gets.chomp

      if    choose_your_fate == "cremate"
        YumemoreFramework::ZombieMode.cremation
      elsif choose_your_fate == "consumption"
        YumemoreFramework::ZombieMode.consumption
      else
        puts ">> Last wishes not understoood, defaulting to self-cremation."
      end
    end
  end
end

module YumemoireHumanMode
  class HumanMode
    ###############################################################################################
    #                                   AI Decision Making                                        #
    ###############################################################################################
    def self.ai_decision
      cchoice = @choice

      ## Determining user data and user choice.
      value = File.read("lib/input/user/user_choice.txt").to_s.to_i

      user_data   = File.readlines("lib/data/user/candidates.txt")
      user_choice = user_data[value]

      ## Processing AI focused data
      ai_choice            = File.read("lib/data/ai/ai_choice.txt").to_s.to_i
      ai_initial_candidate = user_data[ai_choice]
      ai_search_limit      = user_data.size.to_i

      ## Create AI data from user data.
      ai_search_limit.times do
        if ai_choice == user_choice
          #puts "\e[38;2;187;127;118m  The specific candidate was found. Terminating selection..."

          ai_data      = user_data.slice!(ai_choice)

          open("lib/data/ai/candidates.txt", "w") { |f|
            f.puts ai_data
          }
        else
          puts "\e[38;2;187;127;118mL'ennemi découvre que vous n'avez pas fait ce choix...\e[0m"
        end

        sleep(1.5)
      end

      ## AI processing data.
      ai_choice            = File.read("lib/data/ai/ai_choice.txt").to_s.to_i
      ai_data              = File.readlines("lib/data/ai/candidates.txt")
      ai_search_limit      = ai_data.size.to_i
      ai_next_candidate    = ai_data[ai_choice]

      ai_search_limit.times do
        if ai_next_candidate == user_choice
          ai_final_candidate = ai_next_candidate
    
          puts "\e[38;2;187;127;118mCandidate found, processing input...\e[0m"; sleep(1)

          # Breaks the loop if an appropriate candidate is found.

          sleep(1.5)

          conditions = ["Sword", "Stone", "Tarp"]

          decision_made = conditions.sample

          puts "\e[38;2;187;127;118mBy process of elimination, the bot chose: #{ai_data}\e[0m"

          @cchoice = "#{ai_data}"

          puts $cchoice

          break
        else
          ai_choice            = File.read("lib/data/ai/ai_choice.txt").to_s.to_i
          ai_data              = File.readlines("lib/data/ai/candidates.txt")
          ai_search_limit      = ai_data.size.to_i
          ai_next_candidate    = ai_data[ai_choice]

          ai_data      = user_data.slice!(ai_choice).strip

          puts "\e[38;2;187;127;118mEnemy found the option #{ai_data}\e[0m"

          enemy_decision = ["choose", "skip"]

          decision_made = enemy_decision.sample

          if decision_made == "choose"
            puts "\e[38;2;187;127;118mThe enemy chose: #{ai_data}, but found it causes a stalemate. Makes a new decision\e[0m"

            @cchoice = "#{ai_data}"

            enemy_decision = ["Epee", "Ishi", "Bache"]

            decision_made = enemy_decision.sample

            if    decision_made == "Sword"
              @cchoice = "Epee"
            elsif decision_made == "Stone"
              @cchoice = "Ishi"
            elsif decision_made ==  "Tarp"
              @cchoice = "Bache"
            end

            break
          else
            puts "\e[38;2;187;127;118mEnemy weighed the option of choosing #{ai_data}, but decided to skip its turn.\e[0m"

            break
          end

          sleep(1.5)
 
          open("lib/data/ai/candidates.txt", "w") { |f|
            f.puts ai_data
          }
        end
      end
    end

    def self.parser
      loop do
        system("clear")

        if $current_day < $lunar_ticks
          this_day = 29

          puts "\e[38;2;187;127;118mLa prochaine phase lunaire est en cours: #{this_day - $current_day} days...\e[0m"
        else
          lunar_cycle

          # Reset lunar ticks to twenty days away.
          $current_day = 1
        end

        menu = File.read("lib/images/menus/main.txt")

        puts menu

        puts "\e[38;2;187;127;118m[ Currency is #{$player_franc} Francs And #{$player_yen} Yen ]\e[0m"

        puts "\e[38;2;187;127;118m\n[ Stalemates: #{$stalemates} ] [ Player Strikes: #{$player_struck} ] [ Enemy Strikes: #{$enemy_struck} ]\e[0m"
        puts "\e[38;2;187;127;118m  [ #{$player_lunario} Lunario ( You wont need this for most game functions. ) ]"

        puts "\e[38;2;187;127;118m\n\e[0m"
        puts "\e[38;2;187;127;118mSouer De Chaos ( Ana Nuveyatusuki ) HP: #{$player_hp} \e[0m"
        puts "\e[38;2;187;127;118m#{$current_monster_name} HP: #{$enemy_hp}\e[0m"
        #puts "\e[38;2;187;127;118mSouer De Commande ( Ana Nuveyatusuki ) HP: #{$enemy_hp}\e[0m"
        puts "\e[38;2;187;127;118m\n\e[0m"

        if $player_hp <= 0
          system("clear")

          puts "\e[38;2;187;127;118mYou've been zombiefied!\e[0m"

          sleep(1.5)

          YumemoireZombieMode::ZombieMode.parser
        elsif $enemy_hp <= 0
          puts "\e[38;2;187;127;118mYou won\e[0m"

          gets.chomp

          abort
        end

        conditions = {
          "Epee"  =>  "Ishi",
          "Ishi"  => "Bache",
          "Bache" =>  "Epee",
        }

        if $has_spider == true
          puts "\e[38;2;187;127;118mTo heal the player, type: Heal\e[0m"
        else
          puts "\e[38;2;187;127;118mTo heal the player, type: Sleep\e[0m"
        end

        print "\e[38;2;164;145;91m\nEpee, Ishi, or Bache >> \e[0m"
        @choice = gets.chomp.capitalize

        if    @choice == "Epee"
          File.open("lib/input/user/user_choice.txt", "w") { |f|
            f.puts "0"
          }

          # Records a history of player actions.
          File.open("lib/data/user/chosen_action.txt", "a") { |f|
            f.puts "0"
          }
        elsif @choice == "Ishi"
          File.open("lib/input/user/user_choice.txt", "w") { |f|
            f.puts "1"
          }

          # Records a history of player actions.
          File.open("lib/data/user/chosen_action.txt", "a") { |f|
            f.puts "1"
          }
        elsif @choice == "Bache"
          File.open("lib/input/user/user_choice.txt", "w") { |f|
            f.puts "2"
          }

          # Records a history of player actions.
          File.open("lib/data/user/chosen_action.txt", "a") { |f|
            f.puts "2"
          }
        elsif @choice == "Sleep"
          File.open("lib/input/user/user_choice.txt", "w") { |f|
            f.puts "2"
          }

          # Records a history of player actions. This one defaults to bache even though its a distinct action.
          File.open("lib/data/user/chosen_action.txt", "a") { |f|
            f.puts "2"
          }
        elsif @choice == "Heal"
          File.open("lib/input/user/user_choice.txt", "w") { |f|
            f.puts "2"
          }

          # Records a history of player actions. This one defaults to bache even though its a distinct action.
          File.open("lib/data/user/chosen_action.txt", "a") { |f|
            f.puts "2"
          }
        end

        puts " "
        sleep(1.5)

        # Experiment with using an enemy that learns from player's decisions.'
        YumemoireHumanMode::HumanMode.ai_decision

        if conditions[@choice] == @cchoice
          #puts "\e[38;2;187;127;118m  You were struck by the enemy!"

          $enemy_struck = $enemy_struck + 1

          # The amount of damage player gets is based on the enemies attack power.
          #$player_hp = $player_hp - $enemy_atk
          YumemoireDamage::DamageFormulas.enemy_damage_rate
        elsif @cchoice == @choice
          puts "\e[38;2;187;127;118mYou reach a stalemate.\e[0m"

          $stalemates = $stalemates + 1
        elsif conditions[@cchoice] == @choice
          #puts "\e[38;2;187;127;118m  You struck the enemy!"

          $player_struck = $player_struck + 1

          # The amount of damage enemy recieves is based on the player's attack power.
          #$enemy_hp = $enemy_hp - $player_atk
          YumemoireDamage::DamageFormulas.player_damage_rate
        elsif @choice == "Sleep"

          puts "\e[38;2;187;127;118mYou've opted to stay at an inn...'\e[0m"

          sleep(1.5)

          YumemoireVillager::Marketplace.stay_at_inn

        elsif @choice == "Heal"
          puts "\e[38;2;187;127;118mThink quickly or you wont be able to heal properly....'\e[0m"

          sleep(1.5)

          spider_pig_farmer
        else
          puts "\e[38;2;187;127;118m#{@choice} is not a valid option\e[0m"
        end

        $current_day = $current_day + 1
      end
    end
  end
end

module YumemoireEncyclopedia
  class Encyclopedia

    def self.monsternames
      possible_elements = File.readlines("monsternames/elements.txt")

      $chosen_element = possible_elements.sample.strip.to_s

      possible_adjectives = File.readlines("monsternames/gendered_adverb.txt")

      $chosen_adjective = possible_adjectives.sample.strip.to_s 

      $current_monster_name = $chosen_element + " " + $chosen_adjective

      puts "Created monster name: #{$current_monster_name}"
    end

    def self.beastiary
      system("clear")

      beasts = File.read("beasts/beasts.txt")

      puts beasts

      available_beasts = [
        "[Cochonbuta]", "[Ursinehomme]",
        "[Ursinepiros]", "[Kumabatto]",
        "[The Quantumcrusafied]",
      ]

      print "\nWhat kind of beast? ( Cochonbuta / Ursinehomme / Ursinepiros / Kumabatto / The Quantumcrusafied ) << "; do_beast = gets.chomp

      if    do_beast ==           "Cochonbuta"; print available_beasts[0]; puts " Combines a lobster and a boar, related to the spider pig."
      elsif do_beast ==          "Ursinehomme"; print available_beasts[1]; puts " Literally translates to bear-man, is the male version of wearbears. Ursinefemme is the female version."
      elsif do_beast ==          "Ursinepiros"; print available_beasts[2]; puts " Literally translates to vampire-bear, is the human version of wearbears that feeds on human's blood."
      elsif do_beast ==            "Kumabatto"; print available_beasts[3]; puts " A condensed version of 'Le Kumabatto De Les Ghoules', is the king of the bear-bat ghouls."
      elsif do_beast == "The Quantumcrusafied"; print available_beasts[4]; puts " The wandering spirits of men punished for quantum treason by quantum crusafiction."
      else
        puts ">> Not such beast exists on land or sea..."
      end

      gets.chomp
    end

    def self.study
      system("clear")

      word_index = File.read("lib/encyclopedia/encyclopedia/glossary.txt")

      puts word_index

      print "\nWhat word would you like to look up? >> "; research = gets.chomp

      if    research == "Lunario"
        puts "BOB >> This is the largest form of in game currency, and is not used in ordinary game mechanics. It is mainly used for giving offerings to the lunar goddess, or paying the fair for dimension hopping that will come in the tiles version."

        gets.chomp
      elsif research == "Yen"
        puts "BOB >> The smallest form of in game currency, this is mainly used for smaller fair items."

        gets.chomp

      elsif research == "Franc"
        puts "BOB >> This is the largest form of in game currency within the scope of standard in game use. Once the tiles version of released, Lunario exists as travel currency."

        gets.chomp
      elsif research == "RPS"
        puts "BOB >> RPS ia the ancronym for a form of games based on the mechanics of rock, paper, and scissors."

        gets.chomp
      elsif research == "exit"
        abort
      else
      end
    end

    def self.translate
      print "What word would you like to translate? >> "; translate = gets.chomp

      # Get the word count based on how many words are in a sentence.
      #word_count = translate.split(" ").to_i

      dictionary = {
        ## Word Classes

        ## Francophonic
        "Le"  => "The ( Masculine ) [ Francophonic ]",
        "La"  =>  "The ( Feminine ) [ Francophonic ]",
        "Les" =>    "The ( Plural ) [ Francophonic ]",
        "Un"  =>                 "A [ Francophonic ]",
        "Une" =>                "An [ Francophonic ]",
        "Des" =>              "Some [ Francophonic ]",

        ## Japonic
        "Anu"  => "The ( Masculine ) [ Pseudo-Japonic ]",
        "Ana"  =>  "The ( Feminine ) [ Pseudo-Japonic ]",
        "Anos" =>    "The ( Plural ) [ Pseudo-Japonic ]",
        "Tu"   =>                 "A [ Pseudo-Japonic ]",
        "Ta"   =>                "An [ Pseudo-Japonic ]",
        "Tos"  =>             "Some [ Pseudo-Japaonic ]",

        ## German By Route Of Alsatian
        "Der" => "The ( Masculine ) [ Germanic ]",
        "Die" =>  "The ( Feminine ) [ Germanic ]",
        "Das" =>    "The ( Plural ) [ Germanic ]",
        "A"   =>                 "A [ Germanic ]",
        "Ein" =>                "An [ Germanic ]",

        ## Compound Word Specific Word Classes
        "Lanu"  => "The ( masculine ) [ Ahusacos Specific ]",
        "Lana"  =>  "The ( feminine ) [ Ahusacos Specific ]",
        "Lanos" =>    "The ( plural ) [ Ahusacos Specific ]",
        "Tun"   =>                 "A [ Ahusacos Specific ]",
        "Tan"   =>                "An [ Ahusacos Specific ]",
        "Deso"  =>         "It / Some [ Ahusacos Specific ]",

        ## Negation Clauses
        "Ne"   => "Not [ Francophonic ]",
        "Na"   =>      "Not [ Japonic ]",
        "Nix " =>       "Not [ Hybrid ]",
        "Nein" =>     "Not [ Germanic ]",

        ## Personal Pronouns
        "Je"        =>       "I",
        "Vous"      => "You all",
        "Toi"       =>     "You",
        "Nous"      =>      "We",
        "Il"        =>      "He",
        "Ils"       =>     "Him",
        "Elle"      =>     "She",
        "Elles"     =>     "Her",

        ## Common Posessives
        "mien"   =>  "mine",
        "votre"  =>  "your",
        "tien"   => "yours",
        "notre"  =>   "our",
        "notres" =>  "ours",
        "sien"   =>   "his",
        "sienne" =>  "hers",

        ## Not used outside of context of military context, used to refer to groups of units.
        ## In practice, right-wing factions use the wrong plural pronoun to misgender entire units
        ## as a way to lower moral of left-wing factions. Because of this, after the Franco-Japanese
        ## Wars, they stopped being used widely.

        ## War Plurals
        "Nousil"    =>  "He plural",
        "Nousils"   => "Him plural",
        "Nouselle"  => "She plural",
        "Nouselles" => "Her plural",

        ## Plural Posessives
        "sienotre"    =>     "our men",
        "sienenotre"  =>   "our women",
        "sienotres"   =>   "our men's",
        "sienenotres" => "our women's",

        ## Famille / Family

        ### Francophonic
        "Pere"       =>        "Father",
        "Mere"       =>        "Mother",
        "Frere"      =>       "Brother",
        "Soeur"      =>        "Sister",
        "Cousifrere" =>   "Male Cousin",
        "Cousisoeur" => "Female Cousin",
        "Cousiles"   =>  "Both Cousins",
        "Tante"      =>          "Aunt",
        "Oncle"      =>         "Uncle",

        ### Color Acidity Framework
        # These colors are for a system that rates colors based on their acidity or alkalinity.

        ##### Reds
        "PH4DR1" => "Salmon",
        "PH5DR1" => "Pale Salmon",
        "PH4DR3" => "Salmon Pink",

        ##### Oranges
        "PH4DR2" => "Copper",
        "PH8WE1" => "Japanese Bistre",

        ##### Yellow
        "PH6DR1" => "Maize",
        "PH5DR2" => "Khaki",
        "PH6DR3" => "Bland",

        ##### Green
        "PH6DR2" =>     "Pale Lime",
        "PH7NU1" => "Vibrant Green",
        "PH7NU2" =>  "Medium Green",
        "PH8WE2" =>   "Kelly Green",

        ##### Blue
        "PH9WE2" =>       "Viridian",
        "PHAWE3" =>    "Ultramarine",
        "PH9WE3" => "Muted Sapphire",
        "PH8WE3" =>  "Dark Sapphire",
        "PH7NU3" =>      "Grey Blue",

        ##### Purple
        "PH9WE1" => "Dull Purple",
        "PH5DR3" => "Light Mauve",

        ##### Unusual Or Rare Color
        "PH1WE3CH1"    => "Dark Lavender", # A theoretical compound that blends Salmon with Sapphire blue.
        "PH4WE2CH2"    =>  "Atomic Hazel", # A highly toxic combination of copper and arsenic.
        "Atomic Hazel" =>       "#6D6C46", # Hex code for atomic hazel.

        ### Chomatic Shades
        ### Arsenic Scale

        ### Unknown Origin
        "PHAWE1"       =>      "Bordeaux", # I don't know how I got this color.'

        ### Hand Mixed Colors
        "#83b281" => "Dusty Green",

        ### Synthesized From Real Colors
        "#A9A8AD" => "Faded Carolina Blue", # Pale Lime, Salmon Pink, Bland, Grey Blue    [ Hypothesis Acidic Blue ]
        "#A0A5B9" => "Manilla Lavender",    # Salmon, Pale Salmon, Grey Blue, Grey Blue   [ Hypothesis Slightly Alkaline Grey Blue ]
        "#8cc874" => "Asparagus",           # Pale Lime, Maize, Light Mauve, Medium Green [ Hypothesis Alkaline Green ]
        "#a0b36c" => "Tan Green",           # Pale Salmon, Kelly Green, Bland, Khaki      [ Hypothesis Slightly Tan Green ]
        "#5673A9" => "Dusky Blue",          # Grey Blue, Light Mauve, Khaki, Sapphire     [ Hypothesis Highly Alkaline Blue ]
        "#A59C94" => "Warm Grey",           # Vibrant Green, Salmon, Sapphire Dark, Bland [ Hypothesis Slightly Acidic Grey ]

        ### Synthesized From Synthetic Colors
        "#788a9a" => "Steel",               # Faded Carolina Blue, Tan Green, Warm Grey, Dusky Blue [ Hypothesis Slightly Alkaline Medium Chromatic Blue ]
        "#415588" => "Dusky Blue Medium"    # Genetically related to standard Dusky blue. Faded Carolina Blue, Tan Green, Warm Grey, Dusky Blue [ Hypothesis More Shaded Alkaline Blue ]
      }

      print "Your translation: "
      print "#{translate} => #{dictionary[translate]}"
      puts " "

      gets.chomp
    end

    def self.detect_poison
      color_data = File.read("translation/input.txt").strip.to_s

      ## Natural colors
      if    color_data ==          "Salmon";  sleep(1.5); system("./salmonbasic.sh")
      elsif color_data ==     "Pale Salmon";  sleep(1.5); system("./palesalmon.sh")
      elsif color_data ==     "Salmon Pink";  sleep(1.5); system("./salmonpink.sh")
      elsif color_data ==          "Copper";  sleep(1.5); system("./cooper.sh")
      elsif color_data == "Japanese Bistre";  sleep(1.5); system("./japanesebistre.sh")
      elsif color_data ==           "Maize";  sleep(1.5); system("./maize.sh")
      elsif color_data ==           "Khaki";  sleep(1.5); system("./khaki.sh")
      elsif color_data ==           "Bland";  sleep(1.5); system("./bland.sh")
      elsif color_data ==       "Pale Lime";  sleep(1.5); system("./palelime.sh")
      elsif color_data ==   "Vibrant Green";  sleep(1.5); system("./vibrantgreen.sh")
      elsif color_data ==    "Medium Green";  sleep(1.5); system("./mediuemgreen.sh")
      elsif color_data ==     "Kelly Green";  sleep(1.5); system("./kellygreen.sh")
      elsif color_data ==        "Viridian";  sleep(1.5); system("./viridian.sh")
      elsif color_data ==     "Ultramarine";  sleep(1.5); system("./ultramarine.sh")
      elsif color_data ==  "Muted Sapphire";  sleep(1.5); system("./mutedsapphire.sh")
      elsif color_data ==   "Dark Sapphire";  sleep(1.5); system("./darksapphire.sh")
      elsif color_data ==       "Grey Blue";  sleep(1.5); system("./greyblue.sh")
      elsif color_data ==     "Dull Purple";  sleep(1.5); system("./dullpurple.sh")
      elsif color_data ==     "Light Mauve";  sleep(1.5); system("./lightmauve.sh")
      elsif color_data ==   "Dark Lavender";  sleep(1.5); system("./darklavender.sh")
      elsif color_data ==    "Atomic Hazel";  sleep(1.5); system("./atomichazel.sh")

      ## Synthesized Colors
      elsif color_data == "Faded Carolina Blue"; sleep(1.5); system("./fadedcarolinablue.sh")
      elsif color_data == "Dusky Blue";          sleep(1.5); system("./duskyblue.sh")

      ## Double Processed Synthesized Colors

      else
        sleep(1.5)

        puts ">> Either that's not a color, or no color information has yet been found."
      end
    end
  end
end

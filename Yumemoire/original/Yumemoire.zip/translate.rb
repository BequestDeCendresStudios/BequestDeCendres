require_relative "Yumemoire/YumemoireFramework.rb"
#require_relative "Yumemoire/bugtest.rb"

YumemoireEncyclopedia::Encyclopedia.translate
#Game::Encyclopedia.translate

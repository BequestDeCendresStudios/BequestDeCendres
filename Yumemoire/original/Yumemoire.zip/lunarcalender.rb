require_relative "Yumemoire/YumemoireFramework.rb"
require_relative "Yumemoire/bugtest.rb"

YumemoireFramework::GlobalStats.assign_metrics
#Game::HumanMode.parser
YumemoireFramework::LunarCalender.lunar_cycle
